enum StudioDestination {
  home,
  quranStudio,
  adhkar,
  settings,
}

enum AppLanguage {
  arabic('ar', 'العربية', true),
  french('fr', 'Français', false),
  english('en', 'English', false);

  const AppLanguage(this.code, this.nativeLabel, this.isRtl);

  final String code;
  final String nativeLabel;
  final bool isRtl;
}

class ArchitectureModuleSpec {
  final String id;
  final String directoryName;
  final String title;
  final String summary;
  final String phaseStatus;

  const ArchitectureModuleSpec({
    required this.id,
    required this.directoryName,
    required this.title,
    required this.summary,
    required this.phaseStatus,
  });
}
