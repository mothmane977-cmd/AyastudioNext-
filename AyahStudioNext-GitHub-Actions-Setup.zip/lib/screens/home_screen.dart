import 'package:flutter/material.dart';
import '../localization/app_localization.dart';
import '../models/studio_models.dart';
import '../theme/app_theme.dart';
import '../widgets/studio_widgets.dart';

class HomeScreen extends StatelessWidget {
  final LocalizedStrings strings;
  final AppLanguage selectedLanguage;
  final ValueChanged<AppLanguage> onLanguageSelected;
  final ValueChanged<StudioDestination> onNavigate;

  const HomeScreen({
    super.key,
    required this.strings,
    required this.selectedLanguage,
    required this.onLanguageSelected,
    required this.onNavigate,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.lg,
      ),
      children: [
        StudioIdentityHeroCard(
          bismillah: strings.bismillahHeader,
          phaseBadge: strings.phaseBadge,
          title: strings.homeHeroTitle,
          description: strings.homeHeroDescription,
        ),
        const SizedBox(height: AppSpacing.xl),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              strings.languageSettingLabel,
              style: const TextStyle(
                color: AppColors.matteGoldLight,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.2,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: AppColors.emeraldContainer,
                borderRadius: BorderRadius.circular(AppRadii.pill),
                border: Border.all(color: AppColors.emeraldContainerBorder),
              ),
              child: Text(
                '${strings.activeIndicator}: ${selectedLanguage.nativeLabel}',
                style: const TextStyle(
                  color: AppColors.emeraldSoft,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.sm),
        LanguageSelectorBar(
          selectedLanguage: selectedLanguage,
          onLanguageSelected: onLanguageSelected,
        ),
        const SizedBox(height: AppSpacing.xxl),
        Row(
          children: [
            Container(
              width: 3,
              height: 16,
              decoration: BoxDecoration(
                color: AppColors.matteGold,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              strings.quickNavSectionTitle,
              style: const TextStyle(
                color: AppColors.textIvory,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        WorkspaceDestinationCard(
          title: strings.navQuranStudio,
          subtitle: strings.studioPlaceholderSubtitle,
          icon: Icons.video_collection_outlined,
          onTap: () => onNavigate(StudioDestination.quranStudio),
        ),
        WorkspaceDestinationCard(
          title: strings.navAdhkar,
          subtitle: strings.adhkarPlaceholderSubtitle,
          icon: Icons.auto_stories_outlined,
          onTap: () => onNavigate(StudioDestination.adhkar),
        ),
        WorkspaceDestinationCard(
          title: strings.navSettings,
          subtitle: strings.settingsPlaceholderSubtitle,
          icon: Icons.settings_outlined,
          onTap: () => onNavigate(StudioDestination.settings),
        ),
        const SizedBox(height: AppSpacing.xxl),
        Row(
          children: [
            Container(
              width: 3,
              height: 16,
              decoration: BoxDecoration(
                color: AppColors.emeraldPrimary,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                strings.architectureSectionTitle,
                style: const TextStyle(
                  color: AppColors.textIvory,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          strings.architectureSectionSubtitle,
          style: const TextStyle(
            color: AppColors.textSilver,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: AppSpacing.md),
        ...strings.modules.map((module) {
          return ArchitectureModuleCard(module: module);
        }),
        const SizedBox(height: AppSpacing.xl),
      ],
    );
  }
}
