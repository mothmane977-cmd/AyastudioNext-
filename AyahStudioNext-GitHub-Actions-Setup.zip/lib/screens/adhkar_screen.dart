import 'package:flutter/material.dart';
import '../localization/app_localization.dart';
import '../theme/app_theme.dart';
import '../widgets/studio_widgets.dart';

class AdhkarScreen extends StatelessWidget {
  final LocalizedStrings strings;

  const AdhkarScreen({
    super.key,
    required this.strings,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.lg,
      ),
      children: [
        FoundationScopeCard(
          badgeText: strings.phaseBadge,
          title: strings.adhkarPlaceholderTitle,
          subtitle: strings.adhkarPlaceholderSubtitle,
          scopeHeader: strings.adhkarPlannedScopeTitle,
          points: strings.adhkarPlannedPoints,
          icon: Icons.auto_stories_outlined,
        ),
      ],
    );
  }
}
