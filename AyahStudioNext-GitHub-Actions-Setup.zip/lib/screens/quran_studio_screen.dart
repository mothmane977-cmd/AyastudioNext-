import 'package:flutter/material.dart';
import '../localization/app_localization.dart';
import '../theme/app_theme.dart';
import '../video_editing/video_contract.dart';
import '../widgets/studio_widgets.dart';

class QuranStudioScreen extends StatelessWidget {
  final LocalizedStrings strings;

  const QuranStudioScreen({
    super.key,
    required this.strings,
  });

  @override
  Widget build(BuildContext context) {
    const videoStub = PhaseOneVideoEngineStub();

    return ListView(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.lg,
      ),
      children: [
        FoundationScopeCard(
          badgeText: strings.phaseBadge,
          title: strings.studioPlaceholderTitle,
          subtitle: strings.studioPlaceholderSubtitle,
          scopeHeader: strings.studioPlannedScopeTitle,
          points: strings.studioPlannedPoints,
          icon: Icons.video_collection_outlined,
        ),
        const SizedBox(height: AppSpacing.lg),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceNavy,
            borderRadius: BorderRadius.circular(AppRadii.lg),
            border: Border.all(color: AppColors.borderSubtle),
          ),
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.emeraldContainer,
                      borderRadius: BorderRadius.circular(AppRadii.sm),
                      border: Border.all(color: AppColors.emeraldContainerBorder),
                    ),
                    child: const Icon(
                      Icons.aspect_ratio,
                      size: 16,
                      color: AppColors.matteGold,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  const Expanded(
                    child: Text(
                      'video_editing/ • VideoTimelineContract',
                      style: TextStyle(
                        color: AppColors.matteGoldLight,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              Text(
                videoStub.enginePhaseStatus,
                style: const TextStyle(
                  color: AppColors.textSilver,
                  fontSize: 13,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: videoStub.supportedAspectRatios.map((preset) {
                  return Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.emeraldContainer,
                      borderRadius: BorderRadius.circular(AppRadii.sm),
                      border: Border.all(
                        color: AppColors.emeraldPrimary.withOpacity(0.4),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.crop_portrait,
                          size: 13,
                          color: AppColors.matteGold,
                        ),
                        const SizedBox(width: 5),
                        Text(
                          preset.label,
                          style: const TextStyle(
                            color: AppColors.emeraldSoft,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
