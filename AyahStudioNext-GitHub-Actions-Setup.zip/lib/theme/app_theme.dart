import 'package:flutter/material.dart';

/// Centralized Design System Tokens for AyahStudioNext
/// Approved Color Palette:
/// - Midnight Navy: #0B132B
/// - Emerald Green: #2A9D8F
/// - Luxury Matte Gold: #E9C46A
class AppColors {
  // Midnight Navy Foundations
  static const Color midnightNavyDeep = Color(0xFF070B1A);
  static const Color midnightNavy = Color(0xFF0B132B);
  static const Color surfaceNavy = Color(0xFF131E3D);
  static const Color surfaceElevated = Color(0xFF1B2A54);
  static const Color surfaceGlass = Color(0x331B2A54);
  static const Color borderSubtle = Color(0xFF233566);
  static const Color borderProminent = Color(0xFF2E457F);

  // Emerald Green Accents & Containers
  static const Color emeraldPrimary = Color(0xFF2A9D8F);
  static const Color emeraldLight = Color(0xFF48CAE4);
  static const Color emeraldSoft = Color(0xFF52B788);
  static const Color emeraldContainer = Color(0xFF0E3D37);
  static const Color emeraldContainerBorder = Color(0xFF1D6F65);

  // Luxury Matte Gold Highlights & Borders
  static const Color matteGold = Color(0xFFE9C46A);
  static const Color matteGoldLight = Color(0xFFF4E1A4);
  static const Color matteGoldMuted = Color(0xFF9E8443);
  static const Color matteGoldContainer = Color(0xFF332A14);
  static const Color matteGoldBorder = Color(0xFF755F2A);

  // High-legibility Typography & Content
  static const Color textIvory = Color(0xFFF8F9FA);
  static const Color textSilver = Color(0xFFC5CEE0);
  static const Color textMuted = Color(0xFF8898B4);

  // Utility
  static const Color error = Color(0xFFE76F51);
  static const Color success = Color(0xFF2A9D8F);
}

class AppRadii {
  static const double sm = 8.0;
  static const double md = 14.0;
  static const double lg = 20.0;
  static const double xl = 26.0;
  static const double pill = 50.0;
}

class AppSpacing {
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 12.0;
  static const double lg = 16.0;
  static const double xl = 20.0;
  static const double xxl = 28.0;
}

class AppDurations {
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration normal = Duration(milliseconds: 250);
  static const Duration smooth = Duration(milliseconds: 350);
}

class AppTheme {
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.midnightNavy,
      primaryColor: AppColors.matteGold,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.matteGold,
        onPrimary: AppColors.midnightNavyDeep,
        primaryContainer: AppColors.matteGoldContainer,
        onPrimaryContainer: AppColors.matteGoldLight,
        secondary: AppColors.emeraldPrimary,
        onSecondary: AppColors.midnightNavyDeep,
        secondaryContainer: AppColors.emeraldContainer,
        onSecondaryContainer: AppColors.emeraldSoft,
        surface: AppColors.surfaceNavy,
        onSurface: AppColors.textIvory,
        surfaceContainerHighest: AppColors.surfaceElevated,
        outline: AppColors.borderSubtle,
        outlineVariant: AppColors.borderProminent,
        error: AppColors.error,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.midnightNavyDeep,
        foregroundColor: AppColors.textIvory,
        elevation: 0,
        centerTitle: false,
        scrolledUnderElevation: 2,
      ),
      cardTheme: CardTheme(
        color: AppColors.surfaceNavy,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadii.lg),
          side: const BorderSide(color: AppColors.borderSubtle, width: 1),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.midnightNavyDeep,
        selectedItemColor: AppColors.matteGold,
        unselectedItemColor: AppColors.textMuted,
        selectedLabelStyle: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.2,
        ),
        unselectedLabelStyle: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w500,
        ),
        type: BottomNavigationBarType.fixed,
        elevation: 10,
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.borderSubtle,
        thickness: 1,
        space: 24,
      ),
    );
  }
}
