import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ayah_studio_next/main.dart';
import 'package:ayah_studio_next/widgets/studio_widgets.dart';

void main() {
  testWidgets('AyahStudioNext Phase 1 Design System & UI smoke test',
      (WidgetTester tester) async {
    await tester.pumpWidget(const AyahStudioNextApp());
    await tester.pumpAndSettle();

    // 1. Verify Title and Bismillah
    expect(find.text('AyahStudioNext'), findsOneWidget);
    expect(find.text('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ'), findsOneWidget);

    // 2. Verify Persistent Header Language Button exists in AppBar
    expect(find.byType(HeaderLanguageButton), findsOneWidget);

    // 3. Verify Bottom Navigation bar icons exist
    final bottomNav = find.byType(BottomNavigationBar);
    expect(bottomNav, findsOneWidget);
    expect(
        find.descendant(of: bottomNav, matching: find.byIcon(Icons.home)),
        findsOneWidget);
    expect(
        find.descendant(
            of: bottomNav, matching: find.byIcon(Icons.video_collection_outlined)),
        findsOneWidget);
    expect(
        find.descendant(
            of: bottomNav, matching: find.byIcon(Icons.auto_stories_outlined)),
        findsOneWidget);
    expect(
        find.descendant(
            of: bottomNav, matching: find.byIcon(Icons.settings_outlined)),
        findsOneWidget);

    // 4. Navigate to Quran Studio
    await tester.tap(find.descendant(
        of: bottomNav, matching: find.byIcon(Icons.video_collection_outlined)));
    await tester.pumpAndSettle();
    expect(find.text('Quran Studio Workspace'), findsOneWidget);
    expect(find.byType(HeaderLanguageButton), findsOneWidget);

    // 5. Navigate to Adhkar
    await tester.tap(find.descendant(
        of: bottomNav, matching: find.byIcon(Icons.auto_stories_outlined)));
    await tester.pumpAndSettle();
    expect(find.text('Islamic Adhkar & Social Cards'), findsOneWidget);
    expect(find.byType(HeaderLanguageButton), findsOneWidget);

    // 6. Navigate to Settings
    await tester.tap(find.descendant(
        of: bottomNav, matching: find.byIcon(Icons.settings_outlined)));
    await tester.pumpAndSettle();
    expect(find.text('Studio & Localization Preferences'), findsOneWidget);
    expect(find.byType(HeaderLanguageButton), findsOneWidget);

    // 7. Test Language Switcher from Persistent Header Button
    await tester.tap(find.byType(HeaderLanguageButton));
    await tester.pumpAndSettle();

    // The modal bottom sheet opens with all 3 languages
    expect(find.text('Select Interface Language'), findsOneWidget);
    expect(find.text('French (Français)'), findsOneWidget);
    expect(find.text('Arabic (RTL)'), findsOneWidget);

    // Tap French option in sheet
    await tester.tap(find.text('French (Français)'));
    await tester.pumpAndSettle();
    expect(find.text('Studio de Création Vidéo Coranique'), findsOneWidget);

    // Tap Header button again to switch to Arabic
    await tester.tap(find.byType(HeaderLanguageButton));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Arabic (RTL)'));
    await tester.pumpAndSettle();

    // Verify Arabic text is rendered
    expect(find.text('آية ستوديو نكست'), findsOneWidget);
  });
}
