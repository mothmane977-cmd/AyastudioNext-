# AyahStudioNext — GitHub Actions APK build

This package contains the Flutter project and a GitHub Actions workflow to build an APK.
It does not contain a compiled APK; the zero-byte APK placeholders from the original export
were intentionally excluded.

## Build using a separate GitHub repository

1. Create a **new, separate repository** for this project. Do not use or overwrite
   `Ayah-Studio-App-`.
2. Extract this ZIP on a device or computer.
3. Upload the **contents of this folder** to the new repository's root. The root should
   contain `pubspec.yaml`, `lib/`, `android/`, `test/`, and `.github/workflows/build-apk.yml`.
4. Commit the files to the `main` branch.
5. On GitHub, open the new repository → **Actions** → **Build AyahStudioNext APK**.
6. Wait for the workflow to finish. If it fails, open the failed run and read the first
   red error step; do not assume an APK was built.
7. If successful, open the completed run and download the artifact named
   `AyahStudioNext-debug-apk`. The artifact is a ZIP containing `app-debug.apk`.
8. On Android, extract that artifact ZIP and install `app-debug.apk`. Android may ask you
   to allow installation from the browser/file manager.

## Notes

- The workflow runs `flutter pub get`, `flutter test`, and `flutter build apk --debug`.
- The artifact is retained for 7 days, so download it promptly.
- This is a debug APK for testing, not a signed Play Store release.
- This workflow has not been run here; build success is not guaranteed until GitHub Actions
  completes successfully.
- The original uploaded ZIP and the old `Ayah-Studio-App-` repository are not modified.
